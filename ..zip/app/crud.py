from datetime import datetime
from typing import Optional, Tuple

from sqlalchemy.orm import Session
from passlib.context import CryptContext

from . import models

# bcrypt 설치가 안 되어 있으면 sha256_crypt가 더 안정적임
pwd_context = CryptContext(schemes=["sha256_crypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def get_user_by_username(db: Session, username: str) -> Optional[models.User]:
    return db.query(models.User).filter(models.User.username == username).first()


def create_user(db: Session, username: str, password: str, is_admin: bool = False) -> models.User:
    user = models.User(
        username=username,
        password=hash_password(password),
        is_admin=is_admin,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def create_event_with_slots(
    db: Session,
    admin_id: int,
    title: str,
    event_date,
    description: str,
    slots_data: list[dict],
) -> models.Event:
    event = models.Event(
        title=title,
        event_date=event_date,
        description=description,
        created_by=admin_id,
    )
    db.add(event)
    db.flush()

    for slot_data in slots_data:
        slot = models.EventSlot(
            event_id=event.id,
            start_time=slot_data["start_time"],
            capacity=slot_data["capacity"],
            is_active=True,
        )
        db.add(slot)

    db.commit()
    db.refresh(event)
    return event


def user_has_application_in_event(db: Session, user_id: int, event_id: int) -> Optional[models.Application]:
    return (
        db.query(models.Application)
        .filter(
            models.Application.user_id == user_id,
            models.Application.event_id == event_id,
        )
        .first()
    )


def create_application(db: Session, user_id: int, event_id: int, slot_id: int) -> models.Application:
    application = models.Application(
        user_id=user_id,
        event_id=event_id,
        slot_id=slot_id,
        status="pending",
    )
    db.add(application)
    db.commit()
    db.refresh(application)
    return application


def approved_count_for_slot(db: Session, slot_id: int) -> int:
    return (
        db.query(models.Application)
        .filter(
            models.Application.slot_id == slot_id,
            models.Application.status == "approved",
        )
        .count()
    )


def create_notification(db: Session, user_id: int, message: str) -> models.Notification:
    notification = models.Notification(
        user_id=user_id,
        message=message,
        is_read=False,
    )
    db.add(notification)
    db.commit()
    db.refresh(notification)
    return notification


def get_unread_notification_count(db: Session, user_id: int) -> int:
    return (
        db.query(models.Notification)
        .filter(
            models.Notification.user_id == user_id,
            models.Notification.is_read == False,
        )
        .count()
    )


def approve_application(
    db: Session,
    application_id: int,
    admin_id: int,
) -> Tuple[Optional[models.Application], Optional[str]]:
    application = (
        db.query(models.Application)
        .filter(models.Application.id == application_id)
        .first()
    )
    if not application:
        return None, "신청 내역을 찾을 수 없습니다."

    if application.status == "approved":
        return None, "이미 승인된 신청입니다."

    slot = (
        db.query(models.EventSlot)
        .filter(models.EventSlot.id == application.slot_id)
        .first()
    )
    if not slot:
        return None, "슬롯 정보를 찾을 수 없습니다."

    approved_count = approved_count_for_slot(db, slot.id)
    if application.status != "approved" and approved_count >= slot.capacity:
        return None, "해당 슬롯 정원이 이미 가득 찼습니다."

    application.status = "approved"
    application.reviewed_by = admin_id
    application.reviewed_at = datetime.utcnow()

    db.commit()
    db.refresh(application)
    return application, None


def reject_application(
    db: Session,
    application_id: int,
    admin_id: int,
) -> Tuple[Optional[models.Application], Optional[str]]:
    application = (
        db.query(models.Application)
        .filter(models.Application.id == application_id)
        .first()
    )
    if not application:
        return None, "신청 내역을 찾을 수 없습니다."

    if application.status == "rejected":
        return None, "이미 거절된 신청입니다."

    application.status = "rejected"
    application.reviewed_by = admin_id
    application.reviewed_at = datetime.utcnow()

    db.commit()
    db.refresh(application)
    return application, None