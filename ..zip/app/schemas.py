from pydantic import BaseModel
from typing import List, Optional


class SlotCreate(BaseModel):
    start_time: str
    capacity: int


class EventCreate(BaseModel):
    title: str
    event_date: str
    description: Optional[str] = None
    slots: List[SlotCreate]